  <footer class="mt-10 py-8 border-t border-sky-100 text-center text-slate-400 text-sm">
        <p>&copy; WA 2026 - výukový projekt</p>
    </footer>

</body>
</html>